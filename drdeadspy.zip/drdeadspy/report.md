# Project 2 Report

## Memory Program

The memory program creates an array of 100k elements and performs a dead write for each element, since each element in the array is overwritten before a read occurs. The program identifies 101,363 memory dead writes, which is in the range of what we expect. The extra 1,363 dead writes identified can be explained by the overhead to run the program, resulting in additional memory being used.

## Register Program

The register program does the same as the above, except that it uses a `register` variable. However, the code identifies 13,687 register dead writes instead of the expected 100k. This is due to several reasons:

* Compiler optimizations could remove some dead writes
* The `register` keyword is simply a suggestion to the compiler, and does not guarantee the variable will actually be placed in a register. Therefore, some of the elements may not have been placed in a register.